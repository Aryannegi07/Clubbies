# app.py
# Run: python app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
import json, os

app = Flask(__name__)
CORS(app)  # allow frontend to connect

# -------------------------
# Basic Data Structures
# -------------------------
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, item):
        node = Node(item)
        if not self.head:
            self.head = node
            return
        cur = self.head
        while cur.next:
            cur = cur.next
        cur.next = node

    def find(self, predicate):
        cur = self.head
        while cur:
            if predicate(cur.data):
                return cur
            cur = cur.next
        return None

    def remove(self, predicate):
        cur = self.head
        prev = None
        while cur:
            if predicate(cur.data):
                if prev:
                    prev.next = cur.next
                else:
                    self.head = cur.next
                return cur.data
            prev = cur
            cur = cur.next
        return None

    def to_list(self):
        out = []
        cur = self.head
        while cur:
            out.append(cur.data)
            cur = cur.next
        return out

    def clear(self):
        self.head = None

# Simple Queue & Stack
class Queue:
    def __init__(self):
        self.items = []
    def enqueue(self, v): self.items.append(v)
    def dequeue(self): return self.items.pop(0) if self.items else None
    def to_list(self): return list(self.items)
    def size(self): return len(self.items)

class Stack:
    def __init__(self):
        self.items = []
    def push(self, v): self.items.append(v)
    def pop(self): return self.items.pop() if self.items else None
    def peek(self): return self.items[-1] if self.items else None
    def size(self): return len(self.items)

# -------------------------
# Persistence helpers
# -------------------------
DATA_DIR = ".ds_data"
USERS_FILE = os.path.join(DATA_DIR, "users.json")
CLUBS_FILE = os.path.join(DATA_DIR, "clubs.json")
EVENTS_FILE = os.path.join(DATA_DIR, "events.json")

def ensure_data_dir():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)

def load_json(path, default):
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump(default, f, indent=2)
    with open(path) as f:
        return json.load(f)

def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

# -------------------------
# Global DS containers
# -------------------------
users_ll = LinkedList()   # items: {"name","password","clubs":[club_id,...]}
clubs_ll = LinkedList()   # items: {"id","name","emoji","type"}
events_ll = LinkedList()  # items: {"id","club","name","date","description"}

registration_q = Queue()
admin_undo = Stack()

# small helper to generate incremental ids (string)
def next_club_id():
    clubs = clubs_ll.to_list()
    if not clubs: return "1"
    nums = []
    for c in clubs:
        try:
            nums.append(int(c.get("id", "0")))
        except:
            nums.append(0)
    return str(max(nums) + 1)

def next_event_id():
    events = events_ll.to_list()
    if not events: return "1"
    nums = []
    for e in events:
        try:
            nums.append(int(e.get("id", "0")))
        except:
            nums.append(0)
    return str(max(nums) + 1)

# -------------------------
# Load / Save DS <-> JSON
# -------------------------
def load_all():
    ensure_data_dir()
    udat = load_json(USERS_FILE, {"users": []})
    users_ll.clear()
    for u in udat.get("users", []):
        users_ll.append(u)

    cdat = load_json(CLUBS_FILE, {"clubs": []})
    clubs_ll.clear()
    for c in cdat.get("clubs", []):
        clubs_ll.append(c)

    edat = load_json(EVENTS_FILE, {"events": []})
    events_ll.clear()
    for e in edat.get("events", []):
        events_ll.append(e)

def save_all():
    ensure_data_dir()
    save_json(USERS_FILE, {"users": users_ll.to_list()})
    save_json(CLUBS_FILE, {"clubs": clubs_ll.to_list()})
    save_json(EVENTS_FILE, {"events": events_ll.to_list()})

# Initialize with default clubs & some events if empty
def init_defaults():
    load_all()
    if not clubs_ll.head:
        clubs_ll.append({"id":"1","name":"SWARAGINI","emoji":"🎵","type":"Cultural"})
        clubs_ll.append({"id":"2","name":"ARYAVART","emoji":"🖋️","type":"Organising Committee"})
        clubs_ll.append({"id":"3","name":"WIZARD","emoji":"🎮","type":"Gaming Club"})
        clubs_ll.append({"id":"4","name":"THE CREW","emoji":"🔥","type":"Entertainment Club"})

        # default events
        events_ll.append({"id":"1","club":"1","name":"Cultural Night","date":"2025-02-23","description":"An evening of music and dance."})
        events_ll.append({"id":"2","club":"3","name":"LAN Party","date":"2025-03-15","description":"Open gaming tournament."})
        save_all()

# -------------------------
# User operations (DS)
# -------------------------
def user_exists(name):
    return users_ll.find(lambda d: d.get("name","").lower() == name.lower()) is not None

def add_user(name, password):
    if user_exists(name):
        return False
    users_ll.append({"name": name, "password": password, "clubs": []})
    save_all()
    return True

def get_user(name):
    node = users_ll.find(lambda d: d.get("name","").lower() == name.lower())
    return node.data if node else None

def validate_login(name, password):
    node = users_ll.find(lambda d: d.get("name","").lower() == name.lower() and d.get("password") == password)
    return node.data if node else None

def join_club(name, club_id):
    node = users_ll.find(lambda d: d.get("name","").lower() == name.lower())
    if not node:
        return False, "User not found"
    u = node.data
    if club_id in u.get("clubs", []):
        return True, u["clubs"]
    if len(u.get("clubs", [])) >= 2:
        return False, "You can join only 2 clubs!"
    if not clubs_ll.find(lambda c: c.get("id") == club_id):
        return False, "Club not found"
    u["clubs"].append(club_id)
    save_all()
    return True, u["clubs"]

def remove_club_from_user(name, club_id):
    node = users_ll.find(lambda d: d.get("name","").lower() == name.lower())
    if not node:
        return False, "User not found"
    u = node.data
    u["clubs"] = [c for c in u.get("clubs", []) if c != club_id]
    save_all()
    return True, u["clubs"]

# -------------------------
# Club & Event operations (DS)
# -------------------------
def add_club(name, emoji="", ctype="Custom Club"):
    if clubs_ll.find(lambda c: c.get("name","").lower() == name.lower()):
        return False, "Club already exists"
    cid = next_club_id()
    clubs_ll.append({"id": cid, "name": name, "emoji": emoji, "type": ctype})
    save_all()
    return True, cid

def delete_club(club_id, push_undo=True):
    removed = clubs_ll.remove(lambda c: c.get("id") == club_id)
    if not removed:
        return False, "Club not found"
    # collect and remove events of that club
    removed_events = []
    kept = []
    for e in events_ll.to_list():
        if e.get("club") == club_id:
            removed_events.append(e)
        else:
            kept.append(e)
    events_ll.clear()
    for e in kept:
        events_ll.append(e)
    # remove club from all users
    for u in users_ll.to_list():
        u["clubs"] = [c for c in u.get("clubs", []) if c != club_id]
    save_all()
    if push_undo:
        admin_undo.push({"action":"delete_club", "club": removed, "events": removed_events})
    return True, None

def add_event(club_id, name, date, description=""):
    if not clubs_ll.find(lambda c: c.get("id") == club_id):
        return False, "Club not found"
    # prevent duplicate event with same name for same club
    if events_ll.find(lambda e: e.get("club") == club_id and e.get("name","").lower() == name.lower()):
        return False, "Event with same name already exists for this club"
    eid = next_event_id()
    events_ll.append({"id": eid, "club": club_id, "name": name, "date": date, "description": description})
    save_all()
    return True, eid

def delete_event(event_id):
    # ensure comparison as string
    removed = events_ll.remove(lambda e: str(e.get("id")) == str(event_id))
    if not removed:
        return False, "Event not found"
    save_all()
    return True, None

def undo_admin_action():
    act = admin_undo.pop()
    if not act:
        return False, "Nothing to undo"
    if act.get("action") == "delete_club":
        club_obj = act.get("club")
        if club_obj:
            clubs_ll.append(club_obj)
        for e in act.get("events", []):
            events_ll.append(e)
        save_all()
        return True, f"Restored club {club_obj.get('name','?')}"
    return False, "Unknown action"

# -------------------------
# API routes
# -------------------------

@app.post("/signup")
def api_signup():
    data = request.get_json() or {}
    name = data.get("name", "").strip()
    password = data.get("password", "")
    if not name or not password:
        return jsonify(success=False, message="name and password required")
    ok = add_user(name, password)
    if not ok:
        return jsonify(success=False, message="User already exists")
    return jsonify(success=True)

@app.post("/login")
def api_login():
    data = request.get_json() or {}
    name = data.get("name", "").strip()
    password = data.get("password", "")
    if name == "" and password == "":
        return jsonify(success=False, message="name and password required")
    user = validate_login(name, password) if password else get_user(name)
    if user:
        return jsonify(success=True, user=user)
    return jsonify(success=False, message="Invalid login")

@app.get("/clubs")
def api_clubs():
    return jsonify(success=True, clubs=clubs_ll.to_list())

@app.get("/events")
def api_events():
    return jsonify(success=True, events=events_ll.to_list())

@app.post("/join")
def api_join():
    data = request.get_json() or {}
    name = data.get("name", "")
    club_id = data.get("club_id", "")
    if not name or not club_id:
        return jsonify(success=False, message="name and club_id required")
    ok, info = join_club(name, club_id)
    if ok:
        return jsonify(success=True, clubs=info)
    else:
        return jsonify(success=False, message=info)

@app.post("/remove")
def api_remove():
    data = request.get_json() or {}
    name = data.get("name", "")
    club_id = data.get("club_id", "")
    if not name or not club_id:
        return jsonify(success=False, message="name and club_id required")
    ok, info = remove_club_from_user(name, club_id)
    if ok:
        return jsonify(success=True, clubs=info)
    return jsonify(success=False, message=info)

# Admin endpoints
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"

@app.post("/admin-login")
def api_admin_login():
    data = request.get_json() or {}
    username = data.get("username","")
    password = data.get("password","")
    if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
        return jsonify(success=True)
    return jsonify(success=False, message="Invalid admin login")

@app.post("/admin/add-club")
def api_admin_add_club():
    data = request.get_json() or {}
    name = data.get("name","").strip()
    emoji = data.get("emoji","")
    ctype = data.get("type","Custom Club")
    if not name:
        return jsonify(success=False, message="club name required")
    ok, cid_or_msg = add_club(name, emoji, ctype)
    if not ok:
        return jsonify(success=False, message=cid_or_msg)
    return jsonify(success=True, clubs=clubs_ll.to_list())

@app.post("/admin/delete-club")
def api_admin_delete_club():
    data = request.get_json() or {}
    club_id = data.get("club_id","")
    if not club_id:
        return jsonify(success=False, message="club_id required")
    ok, msg = delete_club(club_id, push_undo=True)
    if not ok:
        return jsonify(success=False, message=msg)
    return jsonify(success=True, clubs=clubs_ll.to_list())

@app.post("/admin/add-event")
def api_admin_add_event():
    data = request.get_json() or {}
    club_id = data.get("club_id","")
    name = data.get("name","").strip()
    date = data.get("date","").strip()
    description = data.get("description","")
    if not (club_id and name and date):
        return jsonify(success=False, message="club_id, name and date required")
    ok, eid_or_msg = add_event(club_id, name, date, description)
    if not ok:
        return jsonify(success=False, message=eid_or_msg)
    return jsonify(success=True, events=events_ll.to_list())

@app.post("/admin/delete-event")
def api_admin_delete_event():
    data = request.get_json() or {}
    event_id = data.get("event_id","")
    if not event_id:
        return jsonify(success=False, message="event_id required")
    ok, msg = delete_event(event_id)
    if not ok:
        return jsonify(success=False, message=msg)
    return jsonify(success=True, events=events_ll.to_list())

@app.get("/admin/users")
def api_admin_users():
    return jsonify(success=True, users=users_ll.to_list())

@app.post("/admin/undo")
def api_admin_undo():
    ok, msg = undo_admin_action()
    if ok:
        return jsonify(success=True, message=msg)
    return jsonify(success=False, message=msg)

@app.get("/registrations")
def api_registrations():
    return jsonify(success=True, queue=registration_q.to_list(), size=registration_q.size())

@app.post("/register-event")
def api_register_event():
    data = request.get_json() or {}
    user = data.get("user")
    club = data.get("club")
    event_name = data.get("event")
    if not (user and club and event_name):
        return jsonify(success=False, message="user, club and event required")
    if not users_ll.find(lambda d: d.get("name","").lower() == user.lower()):
        return jsonify(success=False, message="user not found")
    if not clubs_ll.find(lambda c: c.get("id") == club):
        return jsonify(success=False, message="club not found")
    if not events_ll.find(lambda e: e.get("name") == event_name and e.get("club")==club):
        return jsonify(success=False, message="event not found for that club")
    registration_q.enqueue({"user": user, "club": club, "event": event_name})
    return jsonify(success=True, queue_size=registration_q.size())

# -------------------------
# Start server
# -------------------------
if __name__ == "__main__":
    init_defaults()
    print("Starting DS backend on http://127.0.0.1:5000")
    app.run(debug=True, port=5000)
